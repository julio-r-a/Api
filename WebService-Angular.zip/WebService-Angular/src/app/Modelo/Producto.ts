export class Producto{
    codigo : number;
    Nombre : String;
    Descripcion : String;
    Marca : string;
}